clear 
clc
close all
